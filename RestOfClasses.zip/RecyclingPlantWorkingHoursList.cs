﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WASA_EMS
{
    public class RecyclingPlantWorkingHoursList
    {
        public string recyclingPlantLocation { get; set; }
        public string workingHoursPump1 { get; set; }
        public string workingHoursPump2 { get; set; }
        public string workingHoursPump3 { get; set; }
    }
}