﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WASA_EMS
{
    public class ScheduleSlot
    {
        public string time1From { get; set; }
        public string time1To { get; set; }
        public string time2From { get; set; }
        public string time2To { get; set; }
        public string time3From { get; set; }
        public string time3To { get; set; }
        public string time4From { get; set; }
        public string time4To { get; set; }
    }
}