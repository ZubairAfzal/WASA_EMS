﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WASA_EMS
{
    public class DisposalWorkingHoursList
    {
        public string disposalLocation { get; set; }
        public string workingHours { get; set; }
        public string Level1 { get; set; }
        public string Level2 { get; set; }
    }
}