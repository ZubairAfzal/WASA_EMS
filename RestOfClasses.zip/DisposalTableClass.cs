﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WASA_EMS
{
    public class DisposalTableClass
    {
        public string srNo { get; set; }
        public string pondingLocation { get; set; }
        public string currLevel { get; set; }
        public string pUnit { get; set; }
        public string RecTime { get; set; }
        public string flowRateUp { get; set; }
        public string flowRateDown { get; set; }
        public string estClTime { get; set; }
    }
}