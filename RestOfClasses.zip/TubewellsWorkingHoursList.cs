﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WASA_EMS
{
    public class TubewellsWorkingHoursList
    {
        public string tubewellLocation { get; set; }
        public string workingHours { get; set; }
    }
}