﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WASA_EMS
{
    public class ResourceSellector
    {
        public string resourceType { get; set; }
        public string resourceName { get; set; }
    }
}